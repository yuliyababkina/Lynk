import { ArrowUpRight, AlertTriangle, MessageSquare } from "lucide-react";
import type { Ticket, SupplierDoc, TicketStatus } from "@/types";
import { useLynkData } from "@/lib/LynkDataContext";
import { ACTION_ICON } from "@/lib/action-icons";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DetailDrawer } from "@/components/yarowa/detail-drawer";
import { RenewalReviewCard } from "@/components/yarowa/renewal-review-card";
import { TicketStatusMenu } from "@/components/yarowa/ticket-status-menu";
import { CriticalityIcon } from "@/components/yarowa/criticality-icon";
import { useI18n } from "@/lib/i18n";
import { translateTicketTitle, translateAgeLabel } from "@/lib/ticket-i18n";
import { relationshipId } from "@/lib/db";
import { PRINCIPAL_ID } from "@/data";
import type { ChatContext } from "@/types";
import type { View } from "@/App";

const sourceToView: Record<string, View> = {
  "compliance-monitoring": "compliance",
  contracts: "contracts",
  "data-governance": "data-governance",
  onboarding: "onboarding",
};

const sourceLabel: Record<string, string> = {
  "compliance-monitoring": "Compliance Monitoring",
  contracts: "Contract Management",
  "data-governance": "Data Governance",
  onboarding: "Onboarding",
  prospect: "Suppliers",
  "data-quality": "Suppliers",
};

export function TicketDrawer({
  ticket,
  onClose,
  onNavigate,
  onOpenSupplier,
  onResolve,
  onReview,
  onOpenChat,
}: {
  ticket: Ticket;
  onClose: () => void;
  onNavigate: (view: View, selectedId?: string) => void;
  onOpenSupplier: (entityName: string) => void;
  onResolve: (ticket: Ticket, action: string) => void;
  onReview: (doc: SupplierDoc) => void;
  /** Opens the supplier's conversation with this ticket attached. */
  onOpenChat?: (supplierId: string, context: ChatContext) => void;
}) {
  const {
    docs: DOCS,
    contracts: CONTRACTS,
    dataGovernanceRequests: DATA_GOVERNANCE_REQUESTS,
    onboardingCases: ONBOARDING_CASES,
    ticketStatusById,
    setTicketStatus,
    suppliers: SUPPLIERS,
    unreadFor,
  } = useLynkData();
  const { t } = useI18n();
  const status: TicketStatus = ticketStatusById.get(ticket.id) ?? "To do";
  const PrimaryActionIcon = ACTION_ICON[ticket.primaryAction];

  /* A ticket names its entity by display name, so the conversation is found
     the same way "Open supplier" already finds the profile. A ticket about
     something that is not a supplier we hold a relationship with — a stale
     name, a deleted prospect — simply gets no Chat button. */
  const chatSupplier = SUPPLIERS.find((s) => s.name === ticket.entityName);
  const chatUnread = chatSupplier
    ? unreadFor(relationshipId(PRINCIPAL_ID, chatSupplier.id), "principal")
    : 0;
  const openChat = () => {
    if (!chatSupplier) return;
    // The ticket travels as the message's context, so the supplier sees what
    // it is about without the manager retyping it.
    onOpenChat?.(chatSupplier.id, {
      type: doc ? "document" : "data-change",
      id: ticket.targetId ?? ticket.id,
      label: doc?.documentName ?? translateTicketTitle(ticket.title, t),
    });
  };
  const doc = ticket.source === "compliance-monitoring" ? DOCS.find((d) => d.id === ticket.targetId) : undefined;
  const contract = ticket.source === "contracts" ? CONTRACTS.find((c) => c.id === ticket.targetId) : undefined;
  const dgr = ticket.source === "data-governance" ? DATA_GOVERNANCE_REQUESTS.find((r) => r.id === ticket.targetId) : undefined;
  const onb = ticket.source === "onboarding" ? ONBOARDING_CASES.find((o) => o.id === ticket.targetId) : undefined;

  const targetView = sourceToView[ticket.source];

  return (
    <DetailDrawer
      onClose={onClose}
      header={
        <div className="flex flex-col gap-2">
          <div className="flex gap-2">
            <Badge variant={ticket.criticality}>
              <CriticalityIcon criticality={ticket.criticality} />
              {t(ticket.criticality)}
            </Badge>
            <Badge variant="neutral">{t(sourceLabel[ticket.source])}</Badge>
          </div>
          <TicketStatusMenu status={status} onChange={(s) => setTicketStatus(ticket, s)} />
        </div>
      }
    >
      <h3 className="font-semibold text-base mb-3">{translateTicketTitle(ticket.title, t)}</h3>

        <div className="grid grid-cols-2 gap-3 text-xs mb-4">
          <div>
            <div className="text-muted-foreground mb-0.5">{t("ENTITY")}</div>
            <button
              className="text-accent underline font-medium text-left"
              onClick={() => onOpenSupplier(ticket.entityName)}
            >
              {ticket.entityName}
            </button>
          </div>
          <div>
            <div className="text-muted-foreground mb-0.5">{t("TYPE")}</div>
            <div className="font-medium">{t(ticket.entityType)}</div>
          </div>
          <div>
            <div className="text-muted-foreground mb-0.5">{t("OPENED")}</div>
            <div className="font-medium">{translateAgeLabel(ticket.ageLabel, t)}</div>
          </div>
        </div>

        {doc && (
          <div className="border border-border rounded-lg p-3 mb-4 space-y-2 text-xs">
            <div className="font-semibold text-sm">{t(doc.documentName)}</div>
            <div className="text-muted-foreground">
              {t(doc.documentCategory)} · {t("Expires {date}", { date: doc.expiryDate })}
            </div>
            <div className="pt-2 border-t border-border space-y-1">
              {doc.history.map((h, i) => (
                <div key={i}>
                  <span className="font-medium">{h.event}</span> — {h.date} · {h.actor}
                </div>
              ))}
            </div>
          </div>
        )}

        {contract && (
          <div className="border border-border rounded-lg p-3 mb-4 space-y-2 text-xs">
            <div className="font-semibold text-sm">{contract.ref}</div>
            <div className="text-muted-foreground">
              {contract.type} · €{contract.annualValue.toLocaleString()}/yr
            </div>
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <div className="text-muted-foreground">{t("End date")}</div>
                <div className="font-medium">{contract.endDate}</div>
              </div>
              <div>
                <div className="text-muted-foreground">{t("Renewal by")}</div>
                <div className="font-medium">{contract.renewalBy}</div>
              </div>
            </div>
          </div>
        )}

        {dgr && (
          <div className="border border-border rounded-lg p-3 mb-4 space-y-2 text-xs">
            <div className="font-semibold text-sm">{dgr.category} change</div>
            <div className="text-muted-foreground">{dgr.reason}</div>
            <div className="space-y-1.5 pt-1">
              {dgr.fields.map((f) => (
                <div key={f.label} className="flex items-center justify-between gap-2">
                  <span className="text-muted-foreground">{f.label}</span>
                  <span className="font-medium">
                    {f.before} → {f.after}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {onb && (
          <div className="border border-border rounded-lg p-3 mb-4 space-y-2 text-xs">
            <div className="font-semibold text-sm">{onb.companyName}</div>
            <div className="text-muted-foreground">
              {onb.status} · {onb.daysNoResponse}d without response
            </div>
          </div>
        )}

        {doc?.renewal ? (
          <div className="mb-4">
            <RenewalReviewCard doc={doc} onReview={() => onReview(doc)} />
          </div>
        ) : (
          <>
            <div className="text-xs text-muted-foreground mb-4">
              <div className="mb-1 font-medium text-foreground">{t("What needs attention")}</div>
              {t("Review this item and take the recommended action below, or open the full record for more context.")}
            </div>

            <div className="flex flex-col gap-2 mb-4">
              <Button variant="default" className="w-full" onClick={() => onResolve(ticket, ticket.primaryAction)}>
                {PrimaryActionIcon && <PrimaryActionIcon size={14} />}
                {t(ticket.primaryAction)}
              </Button>
              {ticket.primaryAction !== "Escalate" && (
                <Button variant="outline" className="w-full" onClick={() => onResolve(ticket, "Escalate")}>
                  <AlertTriangle size={14} />
                  {t("Escalate")}
                </Button>
              )}
              {/* The supplier portal puts a Chat button on its own tickets, so
                  the same ticket has to be answerable from this side too —
                  otherwise the conversation only ever runs one way. Resolved
                  only for entities we actually hold a relationship with. */}
              {chatSupplier && (
                <Button variant="outline" className="w-full" onClick={openChat}>
                  <MessageSquare size={14} />
                  {t("Chat")}
                  {chatUnread > 0 && (
                    <span className="ml-1 rounded-full bg-critical px-1.5 text-[10px] font-semibold text-white">
                      {chatUnread}
                    </span>
                  )}
                </Button>
              )}
            </div>
          </>
        )}

        {targetView && (
          <button
            onClick={() => onNavigate(targetView, ticket.targetId)}
            className="w-full flex items-center justify-center gap-1.5 text-sm text-accent font-medium py-2 border-t border-border pt-3"
          >
            {t("Open in {view}", { view: t(sourceLabel[ticket.source]) })}
            <ArrowUpRight size={14} />
          </button>
        )}
    </DetailDrawer>
  );
}
