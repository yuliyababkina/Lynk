import {
  ArrowRight,
  Shield,
  FileText,
  PencilLine,
  Upload,
  Send,
  CircleCheck,
  CircleAlert,
  Clock,
  Hourglass,
  TriangleAlert,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { TaskGroupCard, TaskRow } from "@/components/yarowa/task-group-card";
import type { PortalView } from "@/pages/SupplierPortal";
import type { PortalActivitySelection } from "@/components/yarowa/portal-activity-drawer";
import type { ChatContext } from "@/types";
import {
  getPortalProfile,
  primaryActionLabel,
  secondaryActions,
  type ActivityItem,
  type OverviewGroup,
  type PortalStat,
  type PrincipalChip,
  type Tone,
} from "./portal-data";

export interface PortalOverviewProps {
  supplierId: string;
  /** Opens the principal's conversation with this ticket attached. */
  onOpenChat?: (draft: string, context?: ChatContext) => void;
  /** Live groups, owned by SupplierPortal so a fixed ticket moves immediately. */
  groups: OverviewGroup[];
  onNavigate?: (view: PortalView) => void;
  onOpenActivity?: (selection: PortalActivitySelection) => void;
}

// Supplier-portal section iconography — its own set, distinct from the PM
// dashboard's criticality icons. Colour follows the group's tone.
const SECTION_ICON: Record<string, typeof CircleCheck> = {
  "action-required": CircleAlert,
  "expiring-soon": Clock,
  "pending-approval": Hourglass,
  resolved: CircleCheck,
};

const ICON_INK: Record<Tone, string> = {
  critical: "text-critical",
  orange: "text-chart-orange",
  medium: "text-medium",
  success: "text-success",
  warning: "text-warning",
  neutral: "text-muted-foreground",
};

const ACTION_ICON: Record<string, typeof PencilLine> = {
  Update: PencilLine,
  Complete: PencilLine,
  Upload: Upload,
  Chat: Send,
  Remind: Send,
  Review: CircleCheck,
};

function actionVariant(label: string): "default" | "secondary" | "outline" {
  if (label === "Update" || label === "Upload" || label === "Complete") return "default";
  if (label === "Chat") return "secondary";
  return "outline";
}

/* The row itself opens the panel, so the button has to stop the click from
   bubbling — otherwise the row handler fires too, the same reason the PM
   Dashboard guards its inline actions.

   `label` is the English source throughout — it picks the icon and the variant,
   and it is what the drawer matches on — so it is translated only on the way
   to the screen. */
function ActionButton({ label, onClick }: { label: string; onClick?: () => void }) {
  const { t } = useI18n();
  const Icon = ACTION_ICON[label];
  return (
    <Button
      variant={actionVariant(label)}
      onClick={
        onClick &&
        ((e: React.MouseEvent) => {
          e.stopPropagation();
          onClick();
        })
      }
    >
      {Icon && <Icon className="w-4 h-4" />}
      {t(label)}
    </Button>
  );
}

function GroupCard({
  group,
  onOpenActivity,
  onOpenChat,
}: {
  group: OverviewGroup;
  onOpenActivity?: (selection: PortalActivitySelection) => void;
  onOpenChat?: (draft: string, context?: ChatContext) => void;
}) {
  const { t } = useI18n();
  const SectionIcon = SECTION_ICON[group.key] ?? CircleAlert;
  /* `sectionLabel` travels as the English source: the drawer keys its own
     behaviour off it, and translates it for its header badge. */
  const open = (selection: PortalActivitySelection) => onOpenActivity?.(selection);
  return (
    <TaskGroupCard
      icon={<SectionIcon className={cn("w-[17px] h-[17px]", ICON_INK[group.tone])} />}
      label={t(group.label)}
      count={group.items.length}
    >
      {group.items.length > 0 ? (
        group.items.map((item: ActivityItem) => {
          const Icon = item.icon === "shield" ? Shield : FileText;
          return (
            <TaskRow
              key={item.id}
              onClick={() => open({ item, sectionLabel: group.label, tone: group.tone })}
              icon={<Icon className={cn("w-4 h-4", ICON_INK[group.tone])} />}
              title={
                <>
                  {t(item.title)} <span className="font-normal text-muted-foreground">— {t(item.detail)}</span>
                </>
              }
              subline={
                <>
                  {item.principal} · {t(item.ageLabel)}
                </>
              }
              action={
                <div className="flex items-center gap-1.5">
                  {primaryActionLabel(item) && (
                    <ActionButton
                      label={primaryActionLabel(item)!}
                      onClick={() => open({ item, sectionLabel: group.label, tone: group.tone })}
                    />
                  )}
                  {secondaryActions(item).map((a) => (
                    <ActionButton
                      key={a}
                      label={a}
                      onClick={
                        a === "Chat"
                          ? () =>
                              onOpenChat?.(
                                "",
                                item.docName
                                  ? { type: "document", id: item.docName, label: item.docName }
                                  : { type: "data-change", id: item.id, label: item.title }
                              )
                          : undefined
                      }
                    />
                  ))}
                </div>
              }
            />
          );
        })
      ) : (
        <p className="py-6 px-4 text-sm text-muted-foreground text-center">{t("Nothing here right now.")}</p>
      )}
    </TaskGroupCard>
  );
}

const CHIP_ICON: Record<PrincipalChip["tone"], { Icon: typeof CircleCheck; ink: string } | null> = {
  warning: { Icon: TriangleAlert, ink: "text-warning" },
  success: { Icon: CircleCheck, ink: "text-success" },
  neutral: null,
};

function StatTile({ stat, onNavigate }: { stat: PortalStat; onNavigate?: (view: PortalView) => void }) {
  const { t } = useI18n();
  return (
    <Card
      role="button"
      tabIndex={0}
      onClick={() => onNavigate?.(stat.key as PortalView)}
      className="rounded-2xl border border-border ring-0 shadow-none [--card-spacing:1.25rem] px-(--card-spacing) gap-0 cursor-pointer hover:bg-secondary/50 transition-colors"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{t(stat.label)}</p>
        <ArrowRight className="w-4 h-4 text-muted-foreground" />
      </div>
      <p className="text-3xl font-bold mt-2">{stat.value}</p>
      {stat.principals ? (
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2">
          {stat.principals.map((p) => {
            const meta = CHIP_ICON[p.tone];
            return (
              <span key={p.name} className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                {meta && <meta.Icon className={cn("w-3.5 h-3.5", meta.ink)} />}
                {p.name}
              </span>
            );
          })}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground mt-2">{stat.hint ? t(stat.hint) : null}</p>
      )}
    </Card>
  );
}

const QUICK_ACTIONS: {
  icon: typeof Upload;
  title: string;
  hint: string;
  quick: "upload" | "data";
}[] = [
  { icon: Upload, title: "Upload Document", hint: "Renew expiring documents", quick: "upload" },
  { icon: PencilLine, title: "Request Data Change", hint: "IBAN, address updates", quick: "data" },
];

export function PortalOverview({ supplierId, groups, onNavigate, onOpenActivity, onOpenChat }: PortalOverviewProps) {
  const { t } = useI18n();
  const profile = getPortalProfile(supplierId);

  return (
    <div className="@container p-6 space-y-6">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold">{t("Good morning, {name}", { name: profile.firstName })}</h1>
        <p className="text-muted-foreground mt-1">
          {t("Here's the current status of your supplier account with Lynk.")}
        </p>
      </div>

      {/* Stat tiles */}
      <div className="grid grid-cols-1 @min-[44rem]:grid-cols-3 gap-4">
        {profile.stats.map((stat) => (
          <StatTile key={stat.key} stat={stat} onNavigate={onNavigate} />
        ))}
      </div>

      {/* Activity grid. Same rule as the PM Task Queue: two columns only while
          both stay wide enough for a full ticket row, measured on this page's
          width rather than the window's, since the chat dock narrows it. */}
      <div className="grid grid-cols-1 @min-[60rem]:grid-cols-2 gap-4">
        {groups.map((group) => (
          <GroupCard
            key={group.key}
            group={group}
            onOpenActivity={onOpenActivity}
            onOpenChat={onOpenChat}
          />
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-1 @min-[32rem]:grid-cols-2 gap-4">
        {QUICK_ACTIONS.map(({ icon: Icon, title, hint, quick }) => (
          <Card
            key={title}
            role="button"
            tabIndex={0}
            onClick={() => onOpenActivity?.({ quick, sectionLabel: title, tone: "neutral" })}
            className="rounded-2xl border border-border ring-0 shadow-none [--card-spacing:1rem] px-(--card-spacing) cursor-pointer hover:bg-secondary/50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-success-soft text-success-ink flex items-center justify-center shrink-0">
                <Icon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold truncate">{t(title)}</p>
                <p className="text-xs text-muted-foreground truncate">{t(hint)}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
