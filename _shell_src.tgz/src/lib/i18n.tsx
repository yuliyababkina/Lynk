import { createContext, useCallback, useContext, useState, type ReactNode } from "react";

/*
 * Lightweight UI-chrome i18n for the EN/DE language switcher.
 *
 * Keys ARE the English source strings, so `t("Dashboard")` returns "Dashboard"
 * in English and the German override when set. Anything without a German entry
 * falls back to its English source automatically — the spec's required
 * behaviour. This is a chrome-only switch: supplier/document content (catalogues,
 * uploaded files, free-text) is left as authored.
 */
export type Lang = "en" | "de";

// German overrides, keyed by the English source string.
const DE: Record<string, string> = {
  // Brand / header chrome
  "Procurement Platform": "Beschaffungsplattform",
  "Supplier Portal": "Lieferantenportal",
  Switch: "Wechseln",
  "Roles board": "Rollenübersicht",

  // PM sidebar nav
  Dashboard: "Dashboard",
  Suppliers: "Lieferanten",
  "Data Governance": "Datenverwaltung",
  Onboarding: "Onboarding",
  Compliance: "Compliance",
  Contracts: "Verträge",
  Reporting: "Berichte",
  "Service Catalogue": "Leistungskatalog",
  "Invite Supplier": "Lieferant einladen",
  "Procurement Manager": "Einkaufsleiterin",

  // PM view labels (breadcrumb)
  "Suppliers Overview": "Lieferantenübersicht",
  "Supplier Profile": "Lieferantenprofil",
  "Compliance Monitoring": "Compliance-Überwachung",
  "Contract Management": "Vertragsverwaltung",

  // Supplier portal view labels
  Overview: "Übersicht",
  Principals: "Auftraggeber",
  Documents: "Dokumente",
  "Requested Updates": "Angeforderte Änderungen",
  "Price Agreements": "Preisvereinbarungen",
  "Company Details": "Firmendaten",

  // Onboarding wizard stepper
  "Company info": "Firmendaten",
  "Principal Docs": "Auftraggeber-Dokumente",
  Complete: "Abgeschlossen",

  // ── Chat ────────────────────────────────────────────────────────────────
  Chat: "Chat",
  Conversation: "Unterhaltung",
  Messages: "Nachrichten",
  "Write a message": "Nachricht schreiben",
  "Write a message…": "Nachricht schreiben…",
  Send: "Senden",
  "No messages yet. Start the conversation below.":
    "Noch keine Nachrichten. Beginnen Sie die Unterhaltung unten.",
  "Open document": "Dokument öffnen",
  "Open request": "Anfrage öffnen",
  "Open application": "Bewerbung öffnen",
  "Remove link": "Verknüpfung entfernen",
  Yesterday: "Gestern",
  inactive: "inaktiv",
  "New message from {sender}: {body}": "Neue Nachricht von {sender}: {body}",
  "{count} unread": "{count} ungelesen",
  "{count} new messages": "{count} neue Nachrichten",
  "No new messages": "Keine neuen Nachrichten",
  "Notifications": "Benachrichtigungen",
  "Message {company}": "{company} eine Nachricht senden",
  "This application was not approved, so the conversation is closed. It stays here for your records.":
    "Diese Bewerbung wurde nicht genehmigt, daher ist die Unterhaltung geschlossen. Sie bleibt für Ihre Unterlagen erhalten.",
  "This relationship is inactive, so the conversation is closed. It stays here for your records.":
    "Diese Geschäftsbeziehung ist inaktiv, daher ist die Unterhaltung geschlossen. Sie bleibt für Ihre Unterlagen erhalten.",
  "Chat with {principal}": "Chat mit {principal}",
  "Your conversation with {company}": "Ihre Unterhaltung mit {company}",

  // Machine-translation marker (free-form content)
  "Machine translated": "Maschinell übersetzt",
  "Machine translated — not the author's original wording.":
    "Maschinell übersetzt — nicht der Originalwortlaut des Verfassers.",
  "Terms & Conditions": "Allgemeine Geschäftsbedingungen",
  "Please read these before entering your company data.":
    "Bitte lesen Sie diese, bevor Sie Ihre Firmendaten eingeben.",

  // ── Structured / reference data (backend-owned string set) ──────────────
  // Ticket criticality (badges use the raw lowercase value from the data)
  critical: "kritisch",
  high: "hoch",
  medium: "mittel",
  low: "niedrig",
  Critical: "Kritisch",
  High: "Hoch",
  Medium: "Mittel",
  Low: "Niedrig",
  // Ticket categories / filters
  "All tickets": "Alle Tickets",
  "Document compliance": "Dokumenten-Compliance",
  "Data governance": "Datenverwaltung",
  "Service agreements": "Leistungsvereinbarungen",
  "Task Queue": "Aufgabenliste",
  "Sorted by criticality. Click a ticket to open it.":
    "Nach Kritikalität sortiert. Klicken Sie auf ein Ticket, um es zu öffnen.",
  // Compliance document statuses
  Valid: "Gültig",
  "60-Day Warning": "60-Tage-Warnung",
  "30-Day Auto-Notify": "30-Tage-Benachrichtigung",
  "Pending Review": "Prüfung ausstehend",
  "Rejected — Resubmit": "Abgelehnt — erneut einreichen",
  Blocked: "Gesperrt",
  // Compliance tab filters
  All: "Alle",
  "Action Required": "Handlung erforderlich",
  Warnings: "Warnungen",
  Compliant: "Konform",
  // Entity / stage labels
  Prospect: "Interessent",
  Supplier: "Lieferant",
  "Service Provider": "Dienstleister",

  // ── Ticket titles (templated backend strings — see lib/ticket-i18n) ─────
  "{subject} — rejected, resubmission pending": "{subject} — abgelehnt, erneute Einreichung ausstehend",
  "{subject} — {days} days to expiry": "{subject} — {days} Tage bis zum Ablauf",
  "{subject} — expired {days} days ago": "{subject} — vor {days} Tagen abgelaufen",
  "{subject} — expiring in {days} days": "{subject} — läuft in {days} Tagen ab",
  "{subject} — renewal awaiting review": "{subject} — Verlängerung wartet auf Prüfung",
  "{subject} — renewal in progress": "{subject} — Verlängerung in Bearbeitung",
  "Invitation stale — {days} days without response": "Einladung veraltet — {days} Tage ohne Antwort",
  "Invitation sent — 1 day without response": "Einladung gesendet — 1 Tag ohne Antwort",
  "Invitation sent — {days} days without response": "Einladung gesendet — {days} Tage ohne Antwort",
  "Profile completeness {pct}% — below {target}% target":
    "Profilvollständigkeit {pct}% — unter Zielwert {target}%",
  "Profile completeness {pct}% — below {target}% preferred":
    "Profilvollständigkeit {pct}% — unter empfohlenen {target}%",
  "IBAN change request — awaiting second-eye approval": "IBAN-Änderungsantrag — wartet auf Zweitprüfung",
  "IBAN change request — awaiting first-eye endorsement": "IBAN-Änderungsantrag — wartet auf Erstprüfung",
  "Service Catalogue entry — draft, not yet approved":
    "Leistungskatalog-Eintrag — Entwurf, noch nicht genehmigt",

  // Relative age labels
  "{days} days ago": "vor {days} Tagen",
  "1 day ago": "vor 1 Tag",
  Today: "Heute",

  // Ticket actions
  Review: "Prüfen",
  Escalate: "Eskalieren",
  Renew: "Verlängern",
  Remind: "Erinnern",
  Update: "Aktualisieren",
  Upload: "Hochladen",
  Approve: "Genehmigen",
  Request: "Anfordern",

  // Ticket workflow statuses
  "To do": "Offen",
  "In progress": "In Bearbeitung",
  Resolved: "Erledigt",

  // Ticket drawer
  ENTITY: "ENTITÄT",
  TYPE: "TYP",
  OPENED: "GEÖFFNET",
  "What needs attention": "Was Aufmerksamkeit erfordert",
  "Review this item and take the recommended action below, or open the full record for more context.":
    "Prüfen Sie diesen Eintrag und führen Sie die empfohlene Aktion unten aus, oder öffnen Sie den vollständigen Datensatz für mehr Kontext.",
  "Open in {view}": "In {view} öffnen",
  "Expires {date}": "Läuft ab am {date}",

  // ── Contract Management page ────────────────────────────────────────────
  "Framework contracts, renewal deadlines, and full history. No contract lapses without a decision.":
    "Rahmenverträge, Verlängerungsfristen und vollständige Historie. Kein Vertrag läuft ohne Entscheidung aus.",
  "{count} contract require immediate action": "{count} Vertrag erfordert sofortiges Handeln",
  "The renewal deadline has passed or is within 30 days. Initiate renewal or opt-out now to avoid a lapsed contract.":
    "Die Verlängerungsfrist ist abgelaufen oder liegt innerhalb von 30 Tagen. Verlängern Sie jetzt oder treten Sie zurück, um einen ausgelaufenen Vertrag zu vermeiden.",
  "Renewal Urgent": "Verlängerung dringend",
  "Expiring (90d)": "Läuft ab (90 T)",
  Active: "Aktiv",
  "Renewal in Progress": "Verlängerung läuft",
  "Expiring Soon": "Läuft bald ab",
  "Opted Out": "Abgelehnt",
  Urgent: "Dringend",
  Expiring: "Läuft ab",
  Closed: "Geschlossen",
  "SUPPLIER / CONTRACT": "LIEFERANT / VERTRAG",
  "ANNUAL VALUE": "JAHRESWERT",
  "END DATE": "ENDDATUM",
  "TIME LEFT": "RESTZEIT",
  Framework: "Rahmenvertrag",
  "Master Supply": "Rahmenliefervertrag",
  "Service Agreement": "Dienstleistungsvertrag",
  "€{value} per year": "{value} € pro Jahr",
  "Renewal by {date} · {notice} notice req.": "Verlängerung bis {date} · {notice} Kündigungsfrist",

  // ── Reporting page ──────────────────────────────────────────────────────
  "Supplier Performance Report": "Lieferantenleistungsbericht",
  "KPIs, compliance rates, and supplier ratings. Filter before generating for management or audit use.":
    "KPIs, Compliance-Quoten und Lieferantenbewertungen. Filtern Sie vor der Erstellung für Management- oder Prüfzwecke.",
  "Generate Report": "Bericht erstellen",
  "Last 12 months": "Letzte 12 Monate",
  "Compliance Rate": "Compliance-Quote",
  "Avg Supplier Score": "Durchschn. Lieferanten-Score",
  "Active Suppliers": "Aktive Lieferanten",
  "At Risk": "Gefährdet",
  "Critical Flags": "Kritische Kennzeichen",
  "Prospects Pending": "Offene Interessenten",
  "-5pp vs prior period": "-5 PP gegenüber Vorperiode",
  "-1 pts vs prior period": "-1 Pkt. gegenüber Vorperiode",
  "+2 onboarded this period": "+2 in dieser Periode onboardet",
  "red or warning compliance": "rote oder Warn-Compliance",
  "require immediate action": "erfordern sofortiges Handeln",
  "awaiting onboarding completion": "warten auf Abschluss des Onboardings",
  "Compliance Rate & Avg Score Trend": "Trend Compliance-Quote & Durchschn. Score",
  "Across all suppliers · {period}": "Über alle Lieferanten · {period}",
  "Score Distribution": "Score-Verteilung",
  "Active suppliers by score band": "Aktive Lieferanten nach Score-Band",
  "Compliance Rate by Trade": "Compliance-Quote nach Gewerk",
  "Percentage of suppliers with no critical flags":
    "Anteil der Lieferanten ohne kritische Kennzeichen",
  "Network Composition": "Netzwerkzusammensetzung",
  "Contacts by lifecycle stage": "Kontakte nach Lebenszyklusphase",
  Consulting: "Beratung",
  "{count} Prospects": "{count} Interessenten",
  "{count} Suppliers": "{count} Lieferanten",
  "{count} Providers": "{count} Anbieter",
  "{count} total network contacts": "{count} Netzwerkkontakte insgesamt",

  // ── Service Catalogue page ──────────────────────────────────────────────
  "Service catalogues": "Leistungskataloge",
  "Catalog {number} {trade}": "Katalog {number} {trade}",
  "Price lists per Region and Trade, shared with suppliers for confirmation.":
    "Preislisten pro Region und Gewerk, zur Bestätigung an Lieferanten geteilt.",
  "Upload XLS file": "XLS-Datei hochladen",
  "All regions": "Alle Regionen",
  "All types": "Alle Typen",
  "All statuses": "Alle Status",
  Upcoming: "Bevorstehend",
  Draft: "Entwurf",
  "Not shared yet": "Noch nicht geteilt",
  "{confirmed}/{total} Suppliers Confirmed": "{confirmed}/{total} Lieferanten bestätigt",
  "{count} Suppliers to confirm": "{count} Lieferanten müssen bestätigen",

  // ── Send contract & service catalogues (prospect review) ────────────────
  "Next: Send Contract and Service catalogs": "Weiter: Vertrag und Leistungskataloge senden",
  "Reject application": "Bewerbung ablehnen",
  "Request a change": "Änderung anfordern",
  "Send request": "Anfrage senden",
  Cancel: "Abbrechen",
  "What should the supplier update? (shared with the supplier)":
    "Was soll der Lieferant aktualisieren? (wird dem Lieferanten mitgeteilt)",
  "Why is this document being declined? (shared with the supplier)":
    "Warum wird dieses Dokument abgelehnt? (wird dem Lieferanten mitgeteilt)",
  "Send Contract & Service Catalogs": "Vertrag & Leistungskataloge senden",
  "Send Contract": "Vertrag senden",
  "Choose what to send {company} for signature. The case moves to awaiting signature once sent.":
    "Wählen Sie, was {company} zur Unterzeichnung gesendet wird. Der Fall wechselt nach dem Senden in den Status „wartet auf Unterschrift“.",
  "Contract template": "Vertragsvorlage",
  // ("Service catalogues" is already defined with the catalogue page.)
  "Select the price lists that apply to this supplier's work orders.":
    "Wählen Sie die Preislisten, die für die Aufträge dieses Lieferanten gelten.",
  "Select at least one service catalogue.": "Wählen Sie mindestens einen Leistungskatalog.",
  "Send contracts": "Verträge senden",
  "An email with a signing link goes to {email}.":
    "Eine E-Mail mit Signatur-Link geht an {email}.",
  "Awaiting supplier signature": "Wartet auf Unterschrift des Lieferanten",
  "Contract Sent (Pending Signature)": "Vertrag gesendet (Unterschrift ausstehend)",

  // ── Master Data Governance page ─────────────────────────────────────────
  "Master Data Governance": "Stammdatenverwaltung",
  "Sensitive data changes require four-eyes approval before taking effect. Every change is logged to the immutable audit trail.":
    "Änderungen sensibler Daten erfordern eine Vier-Augen-Genehmigung, bevor sie wirksam werden. Jede Änderung wird im unveränderlichen Audit-Trail protokolliert.",
  "{count} critical payment data change awaiting review":
    "{count} kritische Zahlungsdatenänderung wartet auf Prüfung",
  "IBAN and banking changes carry the highest fraud risk. Review carefully and verify with the supplier directly before endorsing.":
    "IBAN- und Bankänderungen bergen das höchste Betrugsrisiko. Prüfen Sie sorgfältig und bestätigen Sie direkt beim Lieferanten, bevor Sie freigeben.",
  "All Requests": "Alle Anträge",
  "Awaiting Review": "Wartet auf Prüfung",
  Endorsed: "Freigegeben",
  "Endorsed — Awaiting 2nd Approval": "Freigegeben — wartet auf 2. Genehmigung",
  Rejected: "Abgelehnt",
  "Payment Data": "Zahlungsdaten",
  "Contact Data": "Kontaktdaten",
  "Requested by {who} · {when}": "Beantragt von {who} · {when}",
  "SUPPLIER'S STATED REASON": "VOM LIEFERANTEN ANGEGEBENER GRUND",
  "{count} FIELDS CHANGING": "{count} FELDER ÄNDERN SICH",
  Before: "Vorher",
  After: "Nachher",
  Sensitive: "Sensibel",
  "Four-eyes approval progress": "Fortschritt der Vier-Augen-Genehmigung",
  "1. First Review": "1. Erstprüfung",
  "2. Final Approval": "2. Endgültige Genehmigung",
  "Reject Change": "Änderung ablehnen",
  "Endorse — First Review": "Freigeben — Erstprüfung",
  "Bank Name": "Name der Bank",

  // ── Onboarding page ─────────────────────────────────────────────────────
  "Prospect invitations that are stale or incomplete. Follow up to keep your pipeline moving.":
    "Einladungen an Interessenten, die veraltet oder unvollständig sind. Bleiben Sie dran, um Ihre Pipeline in Bewegung zu halten.",
  "Open Invitations": "Offene Einladungen",
  Application: "Bewerbung",
  INVITATION: "EINLADUNG",
  "COMPANY INFO": "FIRMENDATEN",
  DOCUMENTS: "DOKUMENTE",
  CONTRACT: "VERTRAG",
  "PRICE AGREEMENTS": "PREISVEREINBARUNGEN",
  "LAST CHANGE": "LETZTE ÄNDERUNG",
  Sent: "Gesendet",
  Added: "Hinzugefügt",
  Uploaded: "Hochgeladen",
  // ("Opened" and "Signed" are already defined above.)
  "Row actions": "Zeilenaktionen",
  "Open full review": "Vollständige Prüfung öffnen",
  "Send reminder": "Erinnerung senden",
  "Revoke Invitation": "Einladung widerrufen",
  "Delete prospect": "Interessent löschen",
  "Invitation revoked": "Einladung widerrufen",
  "Keep invitation": "Einladung behalten",
  // ("Draft" is already defined with the Service Catalogue statuses.)
  "Revoke the invitation for {company}?": "Einladung für {company} widerrufen?",
  "The existing link stops working immediately, so the prospect can no longer open their onboarding. The case stays here as a draft and you can send a new invitation later.":
    "Der bestehende Link funktioniert sofort nicht mehr, der Interessent kann sein Onboarding nicht mehr öffnen. Der Fall bleibt als Entwurf erhalten, und Sie können später eine neue Einladung senden.",
  "No live invitation to remind about": "Keine aktive Einladung für eine Erinnerung",
  "Send a new invitation instead.": "Senden Sie stattdessen eine neue Einladung.",
  "Reminder sent": "Erinnerung gesendet",
  "Could not send the reminder": "Erinnerung konnte nicht gesendet werden",
  "High Priority": "Hohe Priorität",
  Stale: "Veraltet",
  Pending: "Ausstehend",
  Opened: "Geöffnet",
  "Invitation accepted": "Einladung angenommen",
  "In Review": "In Prüfung",
  METRIC: "KENNZAHL",
  "{days}d no response": "{days} T keine Antwort",
  "Submitted — awaiting review": "Eingereicht — wartet auf Prüfung",
  "Activated in Lynk": "In Lynk aktiviert",
  "Changes requested — awaiting resubmission": "Änderungen angefordert — wartet auf erneute Einreichung",
  "{count} cases": "{count} Fälle",
  "Send Reminder": "Erinnerung senden",

  // ── Suppliers Overview page ─────────────────────────────────────────────
  "All contacts — Prospects, Suppliers, and Providers.":
    "Alle Kontakte — Interessenten, Lieferanten und Dienstleister.",
  "Search...": "Suchen…",
  Provider: "Anbieter",
  COMPANY: "UNTERNEHMEN",
  STAGE: "PHASE",
  TRADE: "GEWERK",
  REGION: "REGION",
  TICKETS: "TICKETS",
  COMPLIANCE: "COMPLIANCE",
  RATING: "BEWERTUNG",
  "{count} ticket": "{count} Ticket",
  "{count} tickets": "{count} Tickets",
  // Trades (reference data)
  Plumbing: "Sanitärinstallation",
  "Heating & Plumbing": "Heizung & Sanitär",
  Drywall: "Trockenbau",
  "Building Components": "Bauteile",
  HVAC: "Heizung/Klima",
  Landscaping: "Garten- und Landschaftsbau",
  Renovation: "Renovierung",
  Carpentry: "Zimmerei",
  "Cleaning Services": "Reinigungsdienste",
  "Security Services": "Sicherheitsdienste",
  Roofing: "Dachdeckerei",
  Sanitary: "Sanitär",
  Piping: "Rohrleitungsbau",
  Painting: "Malerarbeiten",
  Electrical: "Elektrotechnik",
  // Regions (reference data)
  Bavaria: "Bayern",
  Hesse: "Hessen",
  "All Germany": "Ganz Deutschland",

  // ── Compliance Monitoring page ──────────────────────────────────────────
  "Continuous document expiry monitoring. Warnings at 60 days, auto-notification at 30 days, auto-block on expiry.":
    "Kontinuierliche Überwachung des Dokumentenablaufs. Warnungen bei 60 Tagen, automatische Benachrichtigung bei 30 Tagen, automatische Sperrung bei Ablauf.",
  "{count} supplier blocked from work orders": "{count} Lieferant von Aufträgen gesperrt",
  "Document expiry passed without renewal. Review any uploaded renewals to reactivate.":
    "Dokument ist ohne Verlängerung abgelaufen. Prüfen Sie hochgeladene Verlängerungen zur Reaktivierung.",
  // ("Action Required" is already defined above with the compliance tab filters.)
  "60-Day Warnings": "60-Tage-Warnungen",
  "Blocked Suppliers": "Gesperrte Lieferanten",
  "Fully Compliant": "Vollständig konform",
  "DOCUMENT / SUPPLIER": "DOKUMENT / LIEFERANT",
  CATEGORY: "KATEGORIE",
  EXPIRY: "ABLAUF",
  STATUS: "STATUS",
  "{days}d remaining": "{days} T verbleibend",
  "Expired {days}d ago": "Vor {days} T abgelaufen",
  "Upload awaiting review": "Upload wartet auf Prüfung",
  // Document categories + supplier trades (reference data)
  Insurance: "Versicherung",
  Certification: "Zertifizierung",
  Licence: "Lizenz",
  Manufacturing: "Fertigung",
  Construction: "Bau",
  Logistics: "Logistik",
  "IT Services": "IT-Dienstleistungen",
  Electronics: "Elektronik",
  // Lifecycle legend
  "Expired → Blocked": "Abgelaufen → Gesperrt",
  "Upload → Review": "Upload → Prüfung",
  "Accept → Reactivated": "Annahme → Reaktiviert",

  // Landing / roles board
  "Supplier Management Platform": "Lieferantenmanagement-Plattform",
  "Three distinct user experiences within the same workflow.":
    "Drei unterschiedliche Nutzererlebnisse im selben Workflow.",
  "Choose a role to explore.": "Wählen Sie eine Rolle zum Erkunden.",
  "Open Procurement Dashboard": "Einkaufs-Dashboard öffnen",
  "Open Supplier Account": "Lieferantenkonto öffnen",
  "Open Onboarding Portal": "Onboarding-Portal öffnen",
  "In production these would be separate authenticated sessions. This demo simulates all three.":
    "In der Produktion wären dies getrennte authentifizierte Sitzungen. Diese Demo simuliert alle drei.",
  "Supplier · EuroBau Components": "Lieferant · EuroBau Components",
  "Prospect · Yilmaz Elektrotechnik": "Interessent · Yilmaz Elektrotechnik",
  "Dashboard, compliance monitoring, contract management, data governance, qualification, reporting.":
    "Dashboard, Compliance-Überwachung, Vertragsverwaltung, Datenverwaltung, Qualifizierung, Berichte.",
  "Manage compliance documents, request sensitive data changes, view performance ratings and score history.":
    "Compliance-Dokumente verwalten, Änderungen sensibler Daten beantragen, Leistungsbewertungen und Score-Verlauf einsehen.",
  "New supplier invited to the platform. Complete profile, upload compliance documents, go through onboarding.":
    "Neuer Lieferant zur Plattform eingeladen. Profil vervollständigen, Compliance-Dokumente hochladen, Onboarding durchlaufen.",

  // ── Prospect onboarding — welcome / consent ─────────────────────────────
  "Welcome, {name}": "Willkommen, {name}",
  "You've been invited to extend your existing supplier relationship to a new Principal — {principal}. Your existing data has been pre-filled. Please review, confirm, and upload any missing documents.":
    "Sie wurden eingeladen, Ihre bestehende Lieferantenbeziehung auf einen neuen Auftraggeber auszuweiten — {principal}. Ihre vorhandenen Daten wurden vorausgefüllt. Bitte prüfen, bestätigen und fehlende Dokumente hochladen.",
  "I have read and agree to the Terms & Conditions and the {privacy}, and I am authorised to accept them for {company}.":
    "Ich habe die Allgemeinen Geschäftsbedingungen und die {privacy} gelesen und stimme ihnen zu, und ich bin berechtigt, diese für {company} zu akzeptieren.",
  "Privacy Policy": "Datenschutzerklärung",
  "Recording your acceptance…": "Ihre Zustimmung wird gespeichert…",
  "Accepted — version {version}": "Akzeptiert — Version {version}",
  "Accept the Terms & Conditions to continue.":
    "Akzeptieren Sie die Allgemeinen Geschäftsbedingungen, um fortzufahren.",
  "This link is private and expires in 72 hours. Your data is protected under GDPR. Only authorised procurement staff at {principal} can access your profile.":
    "Dieser Link ist privat und läuft in 72 Stunden ab. Ihre Daten sind gemäß DSGVO geschützt. Nur autorisierte Einkaufsmitarbeiter von {principal} können auf Ihr Profil zugreifen.",
  "Review & Confirm My Details": "Meine Daten prüfen & bestätigen",
  "Update & Resubmit My Details": "Meine Daten aktualisieren & erneut einreichen",
  "Changes requested by procurement": "Änderungen vom Einkauf angefordert",
  "Please update your details/documents and resubmit.":
    "Bitte aktualisieren Sie Ihre Daten/Dokumente und reichen Sie sie erneut ein.",
  "Application not approved": "Bewerbung nicht genehmigt",

  // ── Prospect onboarding — company details ───────────────────────────────
  // ("Company Details" is already defined above under the portal view labels.)
  "Registered Address": "Eingetragene Adresse",
  "Legal Name": "Firmenname",
  "VAT ID": "USt-IdNr.",
  "Registration No.": "Handelsregister-Nr.",
  Website: "Webseite",
  Street: "Straße",
  City: "Stadt",
  Postcode: "Postleitzahl",
  Country: "Land",
  "Submit My Details": "Meine Daten einreichen",
  Continue: "Weiter",
  Back: "Zurück",
  Approved: "Genehmigt",
  "Approved by procurement": "Vom Einkauf genehmigt",
  "{principal} has verified your company details — no changes needed here.":
    "{principal} hat Ihre Firmendaten geprüft — hier sind keine Änderungen erforderlich.",

  // ── Prospect onboarding — documents ─────────────────────────────────────
  // Document review statuses + browser chrome
  Declined: "Abgelehnt",
  "Pending review": "Prüfung ausstehend",
  "Pending update": "Aktualisierung ausstehend",
  "Pending review {n}/{total}": "Prüfung ausstehend {n}/{total}",
  "Pending update {n}/{total}": "Aktualisierung ausstehend {n}/{total}",
  "Approved {n}/{total}": "Freigegeben {n}/{total}",
  Missing: "Fehlt",
  "Document type": "Dokumententyp",
  "Issued by": "Ausgestellt von",
  Validity: "Gültigkeit",
  // Standard compliance document names (finite, backend-owned reference set)
  "Certificate of Incorporation": "Handelsregisterauszug",
  "VAT Registration Certificate": "USt-Registrierungsbescheinigung",
  "Public Liability Insurance": "Betriebshaftpflichtversicherung",
  "Bank Confirmation Letter": "Bankbestätigungsschreiben",
  "Trade Licence": "Gewerbeschein",
  "ISO 9001 Certificate": "ISO-9001-Zertifikat",
  "Cyber Liability Insurance": "Cyber-Haftpflichtversicherung",
  "Environmental Permit": "Umweltgenehmigung",
  "Conflict Minerals Declaration": "Konfliktmineralien-Erklärung",
  "Standard Compliance Documents": "Standard-Compliance-Dokumente",
  "These documents are required for all suppliers on the Lynk platform.":
    "Diese Dokumente sind für alle Lieferanten auf der Lynk-Plattform erforderlich.",
  "Documents already on file are shown as verified — only upload what's missing.":
    "Bereits hinterlegte Dokumente werden als verifiziert angezeigt — laden Sie nur Fehlendes hoch.",
  "Submit for Review": "Zur Prüfung einreichen",
  "Upload the required documents (Public Liability Insurance, Trade Licence) to continue.":
    "Laden Sie die erforderlichen Dokumente (Betriebshaftpflichtversicherung, Gewerbeschein) hoch, um fortzufahren.",

  // ── Prospect onboarding — contracts ─────────────────────────────────────
  "{principal} has verified your details and documents.":
    "{principal} hat Ihre Daten und Dokumente geprüft.",
  "Review & sign your contracts": "Ihre Verträge prüfen & unterzeichnen",
  "{principal} has sent the documents below — the main agreement and the price catalogues that apply to your work orders. Review each carefully and sign all of them to activate your supplier account.":
    "{principal} hat die untenstehenden Dokumente gesendet — den Hauptvertrag und die Preiskataloge, die für Ihre Aufträge gelten. Prüfen Sie jedes sorgfältig und unterzeichnen Sie alle, um Ihr Lieferantenkonto zu aktivieren.",
  Contract: "Vertrag",
  "Pricing catalogue": "Preiskatalog",
  Signed: "Unterzeichnet",
  "{signed} of {total} signed": "{signed} von {total} unterzeichnet",
  "I have read and agree to this agreement, and I am authorised to sign on behalf of my company.":
    "Ich habe diesen Vertrag gelesen und stimme ihm zu, und ich bin berechtigt, im Namen meines Unternehmens zu unterzeichnen.",
  "I have read and agree to this pricing catalogue, and I am authorised to sign on behalf of my company.":
    "Ich habe diesen Preiskatalog gelesen und stimme ihm zu, und ich bin berechtigt, im Namen meines Unternehmens zu unterzeichnen.",
  "Sign as {name}": "Unterzeichnen als {name}",
  "Signed by {name}": "Unterzeichnet von {name}",
  "Activate supplier account": "Lieferantenkonto aktivieren",
  "You're now a supplier 🎉": "Sie sind jetzt Lieferant 🎉",
  "Contracts signed. {company} is active for {principal} and can now receive work orders. Manage your documents, contracts and details anytime from your supplier portal.":
    "Verträge unterzeichnet. {company} ist für {principal} aktiv und kann nun Aufträge erhalten. Verwalten Sie Ihre Dokumente, Verträge und Daten jederzeit über Ihr Lieferantenportal.",

  // ── Supplier portal ─────────────────────────────────────────────────────
  // The view labels this portal's nav and breadcrumb use are already defined
  // above; what follows is the page chrome inside them.
  "Expand menu": "Menü ausklappen",
  "Collapse menu": "Menü einklappen",
  Close: "Schließen",
  You: "Sie",

  // Overview
  "Good morning, {name}": "Guten Morgen, {name}",
  "Here's the current status of your supplier account with Lynk.":
    "Hier ist der aktuelle Stand Ihres Lieferantenkontos bei Lynk.",
  "Nothing here right now.": "Hier ist derzeit nichts.",
  "You're all caught up": "Sie sind auf dem aktuellen Stand",
  "Open Requests": "Offene Anfragen",
  "Compliance by principal": "Compliance nach Auftraggeber",
  "1 expiring soon": "1 läuft bald ab",
  "1 pending review": "1 wartet auf Prüfung",
  "data change requests": "Datenänderungsanträge",
  "onboarding task": "Onboarding-Aufgabe",
  "Pending Approval": "Warten auf Freigabe",
  "Upload Document": "Dokument hochladen",
  "Renew expiring documents": "Ablaufende Dokumente erneuern",
  "Request Data Change": "Datenänderung beantragen",
  "IBAN, address updates": "IBAN- und Adressänderungen",

  // Activity items (prototype fixtures — a real build sends these translated)
  "Complete company profile": "Firmenprofil vervollständigen",
  "Framework Contract": "Rahmenvertrag",
  "IBAN change request": "IBAN-Änderungsantrag",
  "Profile completeness 61%": "Profilvollständigkeit 61 %",
  "expired 8 days ago": "vor 8 Tagen abgelaufen",
  "expiring in 30 days": "läuft in 30 Tagen ab",
  "12 days to expiry": "12 Tage bis zum Ablauf",
  "below 65% threshold": "unter dem Schwellenwert von 65 %",
  "3 required fields missing": "3 Pflichtfelder fehlen",
  "not yet uploaded": "noch nicht hochgeladen",
  "awaiting principal review": "wartet auf Prüfung durch den Auftraggeber",
  "awaiting first-eye endorsement": "wartet auf Erstprüfung",
  // ("1 day ago" and "Today" are already defined with the relative age labels.)
  "2 days ago": "vor 2 Tagen",
  "3 days ago": "vor 3 Tagen",
  "5 days ago": "vor 5 Tagen",
  "8 days ago": "vor 8 Tagen",
  "Today, 09:14": "Heute, 09:14",
  "Yesterday, 14:02": "Gestern, 14:02",

  // Documents
  "Compliance files shared with your principals, with expiry status and actions.":
    "Compliance-Dokumente, die Sie mit Ihren Auftraggebern teilen — mit Ablaufstatus und Aktionen.",
  "Upload document": "Dokument hochladen",
  "Uploading…": "Wird hochgeladen…",
  "All Documents": "Alle Dokumente",
  "No documents yet — upload your first PDF above.":
    "Noch keine Dokumente — laden Sie oben Ihr erstes PDF hoch.",

  // Company details
  "Legal profile, registered address, and payment data shared with principals.":
    "Rechtliche Angaben, eingetragene Adresse und Zahlungsdaten, die mit Auftraggebern geteilt werden.",
  "Read only": "Nur lesen",
  "Associate: {name}": "Niederlassung: {name}",
  "Update My Details →": "Meine Daten aktualisieren →",
  // Field labels come in as props (see portal-fields.ts), so they never appear
  // as a literal t("…") — the rest of this profile's labels are defined above.
  "Primary Contact": "Hauptansprechpartner",
  "Contact person": "Ansprechpartner",
  "Contact email": "E-Mail des Ansprechpartners",
  "Contact phone": "Telefon des Ansprechpartners",

  // Requested updates
  "Review principal requests, update company data, and confirm changes.":
    "Anfragen der Auftraggeber prüfen, Firmendaten aktualisieren und Änderungen bestätigen.",
  "No pending updates": "Keine offenen Anfragen",
  "All information your principals need is up to date.":
    "Alle Angaben, die Ihre Auftraggeber benötigen, sind aktuell.",
  "Action required": "Handlung erforderlich",
  "Review & update my details →": "Meine Daten prüfen & aktualisieren →",
  "Nothing has changed — confirm current details":
    "Nichts hat sich geändert — aktuelle Daten bestätigen",
  "Requested by 30 Jun 2026": "Angefordert bis 30. Juni 2026",
  "Requested by 22 Jul 2026": "Angefordert bis 22. Juli 2026",
  "Requested by 25 Jul 2026": "Angefordert bis 25. Juli 2026",

  // Price agreements
  "Rate cards and framework pricing agreed with your principals.":
    "Preislisten und Rahmenkonditionen, die mit Ihren Auftraggebern vereinbart wurden.",
  "No price agreements yet": "Noch keine Preisvereinbarungen",
  "When a principal shares a rate card or framework agreement with you, it will appear here for review.":
    "Sobald ein Auftraggeber eine Preisliste oder einen Rahmenvertrag mit Ihnen teilt, erscheint sie hier zur Prüfung.",

  // Principals
  "My Principals": "Meine Auftraggeber",
  "Companies you work with or are onboarding with":
    "Unternehmen, mit denen Sie zusammenarbeiten oder im Onboarding sind",
  "Changes Requested": "Änderungen angefordert",

  // Portal onboarding placeholder
  "Onboarding Coming Soon": "Onboarding folgt in Kürze",
  "The onboarding wizard for prospect relationships will be built here.":
    "Der Onboarding-Assistent für Interessenten-Beziehungen entsteht hier.",

  // ── Invite Supplier wizard ──────────────────────────────────────────────
  // ("Invite Supplier" itself is defined above with the PM sidebar nav.)
  "Send an onboarding invitation to a new supplier":
    "Senden Sie eine Onboarding-Einladung an einen neuen Lieferanten",
  "Search the platform or invite a new supplier by email":
    "Durchsuchen Sie die Plattform oder laden Sie einen neuen Lieferanten per E-Mail ein",
  // Stepper ("Review" is already defined with the ticket actions)
  Contact: "Kontakt",
  Details: "Angaben",
  Settings: "Einstellungen",
  // Contact step
  "Who are you inviting?": "Wen möchten Sie einladen?",
  "Company name": "Firmenname",
  "Search or enter company name…": "Firmenname suchen oder eingeben…",
  "Full name": "Vollständiger Name",
  "Email address": "E-Mail-Adresse",
  // Platform match card
  "{company} is already on Lynk": "{company} ist bereits auf Lynk",
  "{company} is already connected": "{company} ist bereits verbunden",
  "This supplier has a verified profile. Sending a connection request will notify their account manager — no email invite needed.":
    "Dieser Lieferant hat ein verifiziertes Profil. Eine Verbindungsanfrage benachrichtigt seinen Kundenbetreuer — eine E-Mail-Einladung ist nicht nötig.",
  "This supplier is active in your network. You can manage them in the Suppliers Catalogue.":
    "Dieser Lieferant ist in Ihrem Netzwerk aktiv. Sie können ihn im Lieferantenkatalog verwalten.",
  "On Lynk": "Auf Lynk",
  Connected: "Verbunden",
  // Cities (reference data, from the company directory)
  Munich: "München",
  Berlin: "Berlin",
  Stuttgart: "Stuttgart",
  // Details step (the trades themselves are defined with the overview filters)
  "What trades does this supplier cover?": "Welche Gewerke deckt dieser Lieferant ab?",
  Trade: "Gewerk",
  "Search trades…": "Gewerke suchen…",
  "Remove {trade}": "{trade} entfernen",
  "{count} selected": "{count} ausgewählt",
  "Clear all": "Alle entfernen",
  "Select at least one trade to continue":
    "Wählen Sie mindestens ein Gewerk aus, um fortzufahren",
  // Settings step
  "Invitation settings": "Einladungseinstellungen",
  "Send welcome email": "Willkommens-E-Mail senden",
  "The supplier receives a branded onboarding email with a portal link.":
    "Der Lieferant erhält eine gebrandete Onboarding-E-Mail mit einem Portal-Link.",
  "Require onboarding checklist": "Onboarding-Checkliste verlangen",
  "Supplier must complete profile, upload documents, and sign agreements.":
    "Der Lieferant muss sein Profil vervollständigen, Dokumente hochladen und Vereinbarungen unterzeichnen.",
  "Personal note (optional)": "Persönliche Nachricht (optional)",
  "Add a short message for their account manager…":
    "Fügen Sie eine kurze Nachricht für seinen Kundenbetreuer hinzu…",
  "Add a short message that will appear in the invitation email…":
    "Fügen Sie eine kurze Nachricht hinzu, die in der Einladungs-E-Mail erscheint…",
  // Review step ("Prospect" is already defined with the stage badges)
  Company: "Unternehmen",
  Action: "Aktion",
  "Invitation email": "Einladungs-E-Mail",
  Trades: "Gewerke",
  "Welcome email": "Willkommens-E-Mail",
  "Onboarding checklist": "Onboarding-Checkliste",
  "Connection request": "Verbindungsanfrage",
  Yes: "Ja",
  No: "Nein",
  Required: "Erforderlich",
  Optional: "Optional",
  "A connection request will be sent to {company}'s account manager.":
    "Eine Verbindungsanfrage wird an den Kundenbetreuer von {company} gesendet.",
  "An invitation will be sent to {email}. The company will appear as a {prospect} until they complete onboarding.":
    "Eine Einladung wird an {email} gesendet. Das Unternehmen erscheint als {prospect}, bis das Onboarding abgeschlossen ist.",
  // Sending + result toasts
  "Sending connection request…": "Verbindungsanfrage wird gesendet…",
  "Sending invitation…": "Einladung wird gesendet…",
  "Send connection request": "Verbindungsanfrage senden",
  "Send Invitation": "Einladung senden",
  "Connection request sent": "Verbindungsanfrage gesendet",
  "{company}'s account manager was notified.":
    "Der Kundenbetreuer von {company} wurde benachrichtigt.",
  "Invitation sent": "Einladung gesendet",
  "Prospect added": "Interessent hinzugefügt",
  "{company} added as a Prospect — invite emailed to {email}.":
    "{company} als Interessent hinzugefügt — Einladung an {email} gesendet.",
  "{company} added as a Prospect — awaiting onboarding.":
    "{company} als Interessent hinzugefügt — Onboarding steht aus.",
  "Couldn't send invitation": "Einladung konnte nicht gesendet werden",
  "Please try again.": "Bitte versuchen Sie es erneut.",
  "Failed to send invitation email": "Einladungs-E-Mail konnte nicht gesendet werden",

  // ── Document browser + renewal review ───────────────────────────────────
  // Shared by the PM review, the portal and the onboarding wizard, so these
  // belong to every role's vocabulary rather than one screen's.
  "No documents.": "Keine Dokumente.",
  Document: "Dokument",
  "Select a document to preview.": "Wählen Sie ein Dokument zur Vorschau aus.",
  "This certificate does not expire": "Dieses Zertifikat läuft nicht ab",
  // (The "Expires" line is already defined above with the document statuses.)
  "(from file)": "(aus Datei)",
  "Read from the document — not yet confirmed":
    "Aus dem Dokument gelesen — noch nicht bestätigt",
  // Pages within the open document
  "{current} of {total} page": "Seite {current} von {total}",
  "{current} of {total} pages": "Seite {current} von {total}",
  // Moving between documents. The buttons borrow the generic words, the way
  // the English does — the wizard's own footer says "Next" too, and one key
  // cannot hold both "Nächstes (Dokument)" and "Weiter". The tooltips carry
  // the precise wording.
  Previous: "Zurück",
  Next: "Weiter",
  "Previous document": "Vorheriges Dokument",
  "Next document": "Nächstes Dokument",
  "Not yet uploaded.": "Noch nicht hochgeladen.",
  // Renewal review card + lightbox
  "Renewal Uploaded — Awaiting Review": "Verlängerung hochgeladen — wartet auf Prüfung",
  "Uploaded {date}": "Hochgeladen am {date}",
  "Review document": "Dokument prüfen",
  "Review {file}": "{file} prüfen",
  "Review the uploaded renewal, then accept or reject it.":
    "Prüfen Sie die hochgeladene Verlängerung und nehmen Sie sie an oder lehnen Sie sie ab.",
  Reject: "Ablehnen",
  "Accept & Replace": "Annehmen & ersetzen",
  "Accept & Reactivate Supplier": "Annehmen & Lieferant reaktivieren",

  // ── Catalogue preview table ─────────────────────────────────────────────
  "No rows parsed": "Keine Zeilen erkannt",
  "The uploaded file contained no service lines.":
    "Die hochgeladene Datei enthielt keine Leistungszeilen.",
  SERVICE: "LEISTUNG",
  UNIT: "EINHEIT",
  RATE: "SATZ",
  CHANGE: "ÄNDERUNG",
  // ("Added" is already defined with the data-governance change log.)
  Changed: "Geändert",
  Removed: "Entfernt",

  // ── Compliance drawer ───────────────────────────────────────────────────
  // (The status badges, "Expired …d ago" and "…d remaining" are defined above
  // with the Compliance Monitoring page.)
  "Expiry date": "Ablaufdatum",
  "Days remaining": "Verbleibende Tage",
  "Auto-notified": "Automatisch benachrichtigt",
  "View attached document": "Angehängtes Dokument ansehen",
  "Document history": "Dokumentenverlauf",
  // Status callout headings
  "Supplier blocked from work orders": "Lieferant für Aufträge gesperrt",
  "Resubmission required": "Erneute Einreichung erforderlich",
  "Awaiting your review": "Wartet auf Ihre Prüfung",
  "Expiring soon": "Läuft bald ab",
  "30-day auto-notification sent": "30-Tage-Benachrichtigung gesendet",
  "Document valid": "Dokument gültig",
  // Status notes. The three with a supplier name in them are matched as
  // patterns in ticket-i18n.ts, like the ticket titles.
  "{supplier} cannot be assigned new work orders until this document is renewed and accepted. A renewal has been uploaded and is awaiting your review.":
    "{supplier} können keine neuen Aufträge zugewiesen werden, bis dieses Dokument verlängert und angenommen wurde. Eine Verlängerung wurde hochgeladen und wartet auf Ihre Prüfung.",
  "{supplier} cannot be assigned new work orders until this document is renewed and accepted.":
    "{supplier} können keine neuen Aufträge zugewiesen werden, bis dieses Dokument verlängert und angenommen wurde.",
  "The submitted declaration was rejected during review. {supplier} has been asked to correct and resubmit the document.":
    "Die eingereichte Erklärung wurde bei der Prüfung abgelehnt. {supplier} wurde gebeten, das Dokument zu korrigieren und erneut einzureichen.",
  "A renewed certificate has been uploaded ahead of expiry and is awaiting your review before it replaces the current version.":
    "Ein erneuertes Zertifikat wurde vor Ablauf hochgeladen und wartet auf Ihre Prüfung, bevor es die aktuelle Version ersetzt.",
  "A renewed licence has been uploaded and is awaiting your review before it replaces the current version.":
    "Eine erneuerte Lizenz wurde hochgeladen und wartet auf Ihre Prüfung, bevor sie die aktuelle Version ersetzt.",
  "This document expires within 30 days. The 30-day auto-notification has been sent to the supplier portal.":
    "Dieses Dokument läuft innerhalb von 30 Tagen ab. Die 30-Tage-Benachrichtigung wurde an das Lieferantenportal gesendet.",
  "This document expires within 60 days. The supplier has been notified to upload a renewal.":
    "Dieses Dokument läuft innerhalb von 60 Tagen ab. Der Lieferant wurde aufgefordert, eine Verlängerung hochzuladen.",
  "This document is valid and no action is required.":
    "Dieses Dokument ist gültig, es ist keine Handlung erforderlich.",
  // Recommendation banner
  "60-day window — action recommended": "60-Tage-Fenster — Handlung empfohlen",
  "Send a manual reminder now to give the supplier time to prepare their renewal.":
    "Senden Sie jetzt eine manuelle Erinnerung, damit der Lieferant Zeit für die Verlängerung hat.",
  "30-day window — action recommended": "30-Tage-Fenster — Handlung empfohlen",
  "The 30-day auto-notification has been sent. A manual reminder can prompt a faster response.":
    "Die 30-Tage-Benachrichtigung wurde gesendet. Eine manuelle Erinnerung kann eine schnellere Antwort bewirken.",
  "Expired — supplier blocked": "Abgelaufen — Lieferant gesperrt",
  "This document has expired and the supplier is blocked from new work orders until a renewal is uploaded and accepted.":
    "Dieses Dokument ist abgelaufen und der Lieferant ist für neue Aufträge gesperrt, bis eine Verlängerung hochgeladen und angenommen wurde.",
  "The last upload was rejected in review. Ask the supplier to correct and re-submit the document.":
    "Der letzte Upload wurde bei der Prüfung abgelehnt. Bitten Sie den Lieferanten, das Dokument zu korrigieren und erneut einzureichen.",
  // Action cards + their toasts
  "Send Manual Reminder": "Manuelle Erinnerung senden",
  "Notify {supplier} to upload their renewal":
    "{supplier} auffordern, die Verlängerung hochzuladen",
  "Ask {supplier} to correct and re-upload":
    "{supplier} bitten, zu korrigieren und erneut hochzuladen",
  "Escalate to Manager": "An die Leitung eskalieren",
  "Flag this blocked supplier for management review":
    "Diesen gesperrten Lieferanten zur Prüfung durch die Leitung melden",
  "Revoke Supplier Access": "Lieferantenzugang entziehen",
  "Block immediately — re-enable when document is renewed":
    "Sofort sperren — nach Verlängerung des Dokuments wieder freigeben",
  "{supplier} was reminded to renew {document}.":
    "{supplier} wurde an die Verlängerung von {document} erinnert.",
  "Supplier access revoked": "Lieferantenzugang entzogen",
  "{supplier} is blocked from new work orders until {document} is renewed.":
    "{supplier} ist für neue Aufträge gesperrt, bis {document} verlängert wurde.",
  "Escalated to manager": "An die Leitung eskaliert",
  "{document} — {supplier} flagged for review.":
    "{document} — {supplier} zur Prüfung gemeldet.",
  // Document-history timeline (the fixed set the backend writes)
  "Document verified — valid": "Dokument geprüft — gültig",
  "60-day expiry warning triggered": "60-Tage-Ablaufwarnung ausgelöst",
  "30-day auto-notification sent to supplier portal":
    "30-Tage-Benachrichtigung an das Lieferantenportal gesendet",
  "Document expired — supplier blocked from work orders":
    "Dokument abgelaufen — Lieferant für Aufträge gesperrt",
  "Document uploaded by supplier": "Dokument vom Lieferanten hochgeladen",
  "Renewal document uploaded by supplier":
    "Verlängerungsdokument vom Lieferanten hochgeladen",
  "Manual reminder sent": "Manuelle Erinnerung gesendet",
  "Rejected — incomplete smelter list": "Abgelehnt — unvollständige Schmelzhüttenliste",
  "Rejected — missing signature page": "Abgelehnt — fehlende Unterschriftenseite",

  // ── Service-catalogue wizard ────────────────────────────────────────────
  "Cancel and go back": "Abbrechen und zurück",
  "Create a Service catalogue": "Leistungskatalog erstellen",
  "Upload new version — {catalogue}": "Neue Version hochladen — {catalogue}",
  // Stepper ("Upload" and "Details" are defined above)
  Preview: "Vorschau",
  Distribution: "Verteilung",
  // Upload step
  "Drag an XLS file here, or choose one from your computer.":
    "Ziehen Sie eine XLS-Datei hierher oder wählen Sie eine von Ihrem Computer.",
  "Upload the updated price list. It will be compared against the current active version.":
    "Laden Sie die aktualisierte Preisliste hoch. Sie wird mit der aktuellen aktiven Version verglichen.",
  "Upload updated file": "Aktualisierte Datei hochladen",
  "Parsing file…": "Datei wird eingelesen…",
  "Comparing with current version…": "Vergleich mit der aktuellen Version…",
  // Preview step summary tiles
  "Rows added": "Zeilen hinzugefügt",
  "Rows changed": "Zeilen geändert",
  "Rows removed": "Zeilen entfernt",
  "Total rows": "Zeilen gesamt",
  Categories: "Kategorien",
  "Trades detected": "Erkannte Gewerke",
  "Regions detected": "Erkannte Regionen",
  // Details step
  Name: "Name",
  "e.g. Catalog 5 Painting South": "z. B. Katalog 5 Malerarbeiten Süd",
  "New version": "Neue Version",
  Region: "Region",
  "Validity period": "Gültigkeitszeitraum",
  "Supplier response model": "Antwortmodell der Lieferanten",
  "Actively agree": "Aktiv zustimmen",
  "Suppliers must explicitly confirm the catalogue before it applies to them.":
    "Lieferanten müssen den Katalog ausdrücklich bestätigen, bevor er für sie gilt.",
  "Actively disagree": "Aktiv widersprechen",
  "Silence counts as acceptance; suppliers must explicitly opt out.":
    "Schweigen gilt als Zustimmung; Lieferanten müssen ausdrücklich widersprechen.",
  // Distribution step
  "Suppliers matched automatically by {region} + {trade}. Untick any you want to exclude.":
    "Lieferanten wurden automatisch nach {region} + {trade} zugeordnet. Entfernen Sie den Haken bei allen, die Sie ausschließen möchten.",
  "Suppliers linked to this catalogue will be notified to re-confirm {version}.":
    "Mit diesem Katalog verknüpfte Lieferanten werden aufgefordert, {version} erneut zu bestätigen.",
  "the new version": "die neue Version",
  "No matching suppliers": "Keine passenden Lieferanten",
  "No suppliers match this catalogue's region and trade yet.":
    "Noch keine Lieferanten passen zu Region und Gewerk dieses Katalogs.",
  "Select all": "Alle auswählen",
  "Deselect all": "Auswahl aufheben",
  SUPPLIER: "LIEFERANT",
  "Include {supplier}": "{supplier} einbeziehen",
  // Wizard footer
  "Save as draft": "Als Entwurf speichern",
  "Publish & share with suppliers": "Veröffentlichen & mit Lieferanten teilen",
  "Publish & notify suppliers": "Veröffentlichen & Lieferanten benachrichtigen",

  // ── App shell, boot and preview chrome ──────────────────────────────────
  "Couldn't load Lynk data": "Lynk-Daten konnten nicht geladen werden",
  "Loading Lynk…": "Lynk wird geladen…",
  "This invitation link isn't valid": "Dieser Einladungslink ist ungültig",
  "It may have expired or already been used. Contact the company that invited you for a new link.":
    "Er ist möglicherweise abgelaufen oder wurde bereits verwendet. Wenden Sie sich für einen neuen Link an das Unternehmen, das Sie eingeladen hat.",
  Language: "Sprache",
  "Switch account": "Konto wechseln",
  Dismiss: "Schließen",
  "Loading document…": "Dokument wird geladen…",
  "Couldn't render the preview.": "Die Vorschau konnte nicht dargestellt werden.",
  "Open in a new tab": "In neuem Tab öffnen",
  "Open in new tab": "In neuem Tab öffnen",
  "not submitted yet": "noch nicht eingereicht",
  "Preview attached document": "Angehängtes Dokument ansehen",
  "e.g. TÜV Süd, Chamber of Commerce, Allianz": "z. B. TÜV Süd, Handelskammer, Allianz",

  // ── Supplier profile ────────────────────────────────────────────────────
  "Health Score": "Health-Score",
  "Open Tickets": "Offene Tickets",
  "No open tickets.": "Keine offenen Tickets.",
  Contacts: "Kontakte",
  Primary: "Hauptkontakt",
  Services: "Leistungen",
  "Trade Categories": "Gewerkekategorien",
  "Regions Served": "Betreute Regionen",
  Capabilities: "Fähigkeiten",
  "{count} on file": "{count} hinterlegt",
  "No documents on file.": "Keine Dokumente hinterlegt.",
  "View all": "Alle anzeigen",
  "Activity Timeline": "Aktivitätsverlauf",
  Edit: "Bearbeiten",
  // ("Contracts", "Documents" and "Suppliers Overview" are defined above.)

  // ── Ticket drawer ───────────────────────────────────────────────────────
  "End date": "Enddatum",
  "Renewal by": "Verlängerung bis",

  // ── Portal activity panel ───────────────────────────────────────────────
  "CURRENT FILE": "AKTUELLE DATEI",
  "Not uploaded yet": "Noch nicht hochgeladen",
  "Expired {days} days ago": "Vor {days} Tagen abgelaufen",
  "Expires today": "Läuft heute ab",
  "Expiring in {days} days": "Läuft in {days} Tagen ab",
  "SUBMITTED FOR REVIEW": "ZUR PRÜFUNG EINGEREICHT",
  "Not on file": "Nicht hinterlegt",
  "Does not expire": "Läuft nicht ab",
  "Stand-in page — this document isn't in the document store yet, so there is no file to render.":
    "Platzhalterseite — dieses Dokument liegt noch nicht im Dokumentenspeicher, es gibt also keine Datei zum Anzeigen.",
  "SUBMITTED FOR APPROVAL": "ZUR FREIGABE EINGEREICHT",
  "WHAT YOU CHANGED": "WAS SIE GEÄNDERT HABEN",
  "Your current details stay active until this is endorsed.":
    "Ihre aktuellen Daten bleiben aktiv, bis dies bestätigt wurde.",
  "Applied to your profile and shared with your principals.":
    "In Ihr Profil übernommen und mit Ihren Auftraggebern geteilt.",
  "Request a data change": "Datenänderung beantragen",
  "Upload a document": "Dokument hochladen",
  "Correct your company profile": "Firmenprofil korrigieren",
  "Add or renew a compliance file": "Compliance-Dokument hinzufügen oder erneuern",
  PRINCIPAL: "AUFTRAGGEBER",
  UPDATED: "AKTUALISIERT",
  "Saved together with the file.": "Wird zusammen mit der Datei gespeichert.",
  "Submit for approval": "Zur Freigabe einreichen",
  "Save changes": "Änderungen speichern",
  "Waiting on your principal. Here is exactly what they received.":
    "Wartet auf Ihren Auftraggeber. Das hier hat er genau erhalten.",
  "Closed — kept here so you can see what was submitted.":
    "Abgeschlossen — hier aufbewahrt, damit Sie sehen, was eingereicht wurde.",
  "Nothing recorded for this item.": "Zu diesem Eintrag ist nichts erfasst.",
  "Discard your changes?": "Änderungen verwerfen?",
  "The file you picked hasn't been submitted.": "Die gewählte Datei wurde nicht eingereicht.",
  "Your edits haven't been saved.": "Ihre Änderungen wurden nicht gespeichert.",
  "Keep editing": "Weiter bearbeiten",
  Discard: "Verwerfen",
  "Choose a file to continue.": "Wählen Sie eine Datei, um fortzufahren.",
  "Document submitted": "Dokument eingereicht",
  "{document} is now awaiting review.": "{document} wartet nun auf Prüfung.",
  "Your document": "Ihr Dokument",
  "Submitted for approval": "Zur Freigabe eingereicht",
  "{count} change sent for endorsement.": "{count} Änderung zur Bestätigung gesendet.",
  "{count} changes sent for endorsement.": "{count} Änderungen zur Bestätigung gesendet.",

  // ── Onboarding (PM side) ────────────────────────────────────────────────
  "Company details": "Firmendaten",
  "Registered address": "Eingetragene Adresse",
  "Primary contact": "Hauptansprechpartner",
  "No documents submitted yet.": "Noch keine Dokumente eingereicht.",
  "PM Review": "Prüfung durch den Einkauf",
  "Invitation timeline": "Verlauf der Einladung",
  "Invitation sent, {days} days ago. No response from contact yet.":
    "Einladung vor {days} Tagen gesendet. Noch keine Antwort des Kontakts.",
  "Delete {company}?": "{company} löschen?",
  "The onboarding case is removed. The supplier profile stays, because it is already active in Lynk. This can't be undone.":
    "Der Onboarding-Fall wird entfernt. Das Lieferantenprofil bleibt bestehen, da es in Lynk bereits aktiv ist. Dies kann nicht rückgängig gemacht werden.",
  "The case and the prospect's profile are removed. This can't be undone — reject the application instead if the supplier should be told the outcome.":
    "Der Fall und das Profil des Interessenten werden entfernt. Dies kann nicht rückgängig gemacht werden — lehnen Sie die Bewerbung stattdessen ab, wenn der Lieferant das Ergebnis erfahren soll.",
  "The case, the prospect's profile and {count} uploaded document are removed. This can't be undone — reject the application instead if the supplier should be told the outcome.":
    "Der Fall, das Profil des Interessenten und {count} hochgeladenes Dokument werden entfernt. Dies kann nicht rückgängig gemacht werden — lehnen Sie die Bewerbung stattdessen ab, wenn der Lieferant das Ergebnis erfahren soll.",
  "The case, the prospect's profile and {count} uploaded documents are removed. This can't be undone — reject the application instead if the supplier should be told the outcome.":
    "Der Fall, das Profil des Interessenten und {count} hochgeladene Dokumente werden entfernt. Dies kann nicht rückgängig gemacht werden — lehnen Sie die Bewerbung stattdessen ab, wenn der Lieferant das Ergebnis erfahren soll.",
  "Reason for deleting": "Grund für die Löschung",
  "e.g. duplicate invitation, company no longer trading, invited in error":
    "z. B. doppelte Einladung, Unternehmen nicht mehr tätig, versehentlich eingeladen",
  "Kept in the activity log — the only record left once the case is gone.":
    "Wird im Aktivitätsprotokoll festgehalten — der einzige Nachweis, der nach dem Löschen bleibt.",
  "Keep case": "Fall behalten",
  "Delete case": "Fall löschen",
  "Give a reason to enable deletion.": "Geben Sie einen Grund an, um das Löschen freizugeben.",
  "Could not delete the case.": "Der Fall konnte nicht gelöscht werden.",

  // ── Prospect onboarding (supplier side) ─────────────────────────────────
  "Review document details": "Dokumentdetails prüfen",
  "Confirm the details below so your principals can verify this document.":
    "Bestätigen Sie die folgenden Angaben, damit Ihre Auftraggeber dieses Dokument verifizieren können.",
  "Edit document details": "Dokumentdetails bearbeiten",
  "Correct what this document says. The uploaded file itself isn't changed.":
    "Korrigieren Sie die Angaben zu diesem Dokument. Die hochgeladene Datei selbst wird nicht verändert.",
  "Correct what this document says. The uploaded file itself isn't changed — because procurement already approved these details, the document goes back for review.":
    "Korrigieren Sie die Angaben zu diesem Dokument. Die hochgeladene Datei selbst wird nicht verändert — da der Einkauf diese Angaben bereits freigegeben hat, geht das Dokument erneut in die Prüfung.",
  "Edit details": "Details bearbeiten",
  "Edit the details of {document}": "Details von {document} bearbeiten",
  "Delete document": "Dokument löschen",
  "Delete {document}": "{document} löschen",
  "Terms and Conditions": "Allgemeine Geschäftsbedingungen",
  // ("Signed" is already defined above with the contract signing step.)
  "Awaiting signature": "Wartet auf Unterschrift",
  "You're all done!": "Sie sind fertig!",
  "Your profile and all required documents have been submitted. {manager} at Lynk will now complete the qualification review. You'll receive an email once a decision has been made.":
    "Ihr Profil und alle erforderlichen Dokumente wurden eingereicht. {manager} bei Lynk schließt nun die Qualifizierungsprüfung ab. Sie erhalten eine E-Mail, sobald eine Entscheidung getroffen wurde.",
  "What happens next": "Wie es weitergeht",
  "Procurement team reviews your qualification score":
    "Der Einkauf prüft Ihren Qualifizierungs-Score",
  "You'll be notified by email of the outcome":
    "Sie werden per E-Mail über das Ergebnis informiert",
  "If approved, {principal} will send you the main contract and pricing catalogues to review and sign":
    "Bei Freigabe sendet Ihnen {principal} den Hauptvertrag und die Preiskataloge zur Prüfung und Unterzeichnung",
  "Signing the contracts activates your supplier account":
    "Mit der Unterzeichnung der Verträge wird Ihr Lieferantenkonto aktiviert",
  "Your data is protected under GDPR. You can request deletion at any time.":
    "Ihre Daten sind nach DSGVO geschützt. Sie können jederzeit deren Löschung verlangen.",

  // ── Prospect review (PM side) ───────────────────────────────────────────
  "Uploaded documents": "Hochgeladene Dokumente",
  "Review each document — open the preview, then approve or decline with a comment.":
    "Prüfen Sie jedes Dokument — öffnen Sie die Vorschau und geben Sie es dann frei oder lehnen Sie es mit einem Kommentar ab.",
  "Verified and accepted": "Geprüft und angenommen",
  "Fix requested": "Korrektur angefordert",
  "Section confirmed": "Abschnitt bestätigt",
  Undo: "Rückgängig",
  "Save comment": "Kommentar speichern",
  "Confirm section": "Abschnitt bestätigen",
  "Request a fix / comment": "Korrektur anfordern / kommentieren",
  "What does the supplier need to fix in this section?":
    "Was muss der Lieferant in diesem Abschnitt korrigieren?",
  "This clears the submitted application and returns the case to {status}. The existing magic link keeps working, so the prospect can start over.":
    "Dies löscht die eingereichte Bewerbung und setzt den Fall zurück auf {status}. Der bestehende Magic Link funktioniert weiter, sodass der Interessent neu beginnen kann.",
  Invited: "Eingeladen",
  "Reason for rejection (shared with the supplier)":
    "Ablehnungsgrund (wird dem Lieferanten mitgeteilt)",
  "Review / edit": "Prüfen / bearbeiten",
  "Edit {section}": "{section} bearbeiten",

  // ── Service catalogue list + detail ─────────────────────────────────────
  "Upload a price list of services scoped by Region and Trade, then share it with your suppliers for confirmation.":
    "Laden Sie eine Preisliste für Leistungen nach Region und Gewerk hoch und teilen Sie sie dann zur Bestätigung mit Ihren Lieferanten.",
  "Service catalogue alerts": "Hinweise zum Leistungskatalog",
  "All suppliers compliant": "Alle Lieferanten konform",
  "Not confirmed": "Nicht bestätigt",
  "History log": "Versionsverlauf",
  Current: "Aktuell",

  // ── Supplier profile: metrics, master data and reference values ─────────
  "Last active {when}": "Zuletzt aktiv {when}",
  "{valid}/{total} valid": "{valid}/{total} gültig",
  Good: "Gut",
  Warning: "Warnung",
  Expired: "Abgelaufen",
  "Valid to {date}": "Gültig bis {date}",
  "No contracts on file.": "Keine Verträge hinterlegt.",
  "Master Data": "Stammdaten",
  // ("VAT ID" is already defined with the company-details fields; "IBAN" and
  //  "Address" read the same in German, so the fallback covers them.)
  "IBAN change request pending four-eyes approval":
    "IBAN-Änderungsantrag wartet auf Vier-Augen-Freigabe",
  "Request Renewal": "Verlängerung anfordern",
  "2 hours ago": "vor 2 Stunden",
  // Reference data the profile renders (regions, capabilities)
  Saxony: "Sachsen",
  "Precision manufacturing": "Präzisionsfertigung",
  "Site Safety": "Arbeitssicherheit",
  // Contact roles. Neutral forms: these describe whoever holds the role, not
  // one particular person (unlike "Procurement Manager" above, which is
  // Sabine's own title).
  Owner: "Inhaber/in",
  "Finance Director": "Leitung Finanzen",
  "Procurement Lead": "Leitung Einkauf",
  // The third completeness wording the ticket titles use
  "Profile completeness {pct}% — below {target}% threshold":
    "Profilvollständigkeit {pct}% — unter Schwellenwert {target}%",

  // ── Compact upload dropzone (the 380px detail rail) ─────────────────────
  "Drop a PDF here": "PDF hierher ziehen",
  "Browse files": "Dateien durchsuchen",
  "PDF only · up to {max} MB": "Nur PDF · bis {max} MB",
  // Document category as the portal prints it
  "Insurance Policy": "Versicherungspolice",

  // ── Onboarding review pane and its decision buttons ─────────────────────
  "Legal name": "Firmenname",
  "Documents ({count})": "Dokumente ({count})",
  "Accept application": "Bewerbung annehmen",
  "Request changes": "Änderungen anfordern",
  // ("Reject" is already defined with the renewal decision buttons.)
  "What does the supplier need to change?": "Was muss der Lieferant ändern?",
  "Reason for rejection": "Ablehnungsgrund",
  "Send feedback": "Rückmeldung senden",
  "Confirm rejection": "Ablehnung bestätigen",
  "Accepted — supplier profile is now active in Lynk. A confirmation email was sent.":
    "Angenommen — das Lieferantenprofil ist jetzt in Lynk aktiv. Eine Bestätigungs-E-Mail wurde gesendet.",
  "Application rejected.": "Bewerbung abgelehnt.",
  "Changes requested — awaiting the supplier's resubmission.":
    "Änderungen angefordert — wartet auf die erneute Einreichung des Lieferanten.",
};

const STORAGE_KEY = "lynk-lang";

/** Values substituted into `{placeholder}` slots in a string. */
export type TVars = Record<string, string | number>;

interface I18nValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  /**
   * Translate a source string. `{name}`-style placeholders let the translation
   * put interpolated values where that language's grammar needs them, instead of
   * concatenating fragments.
   */
  t: (source: string, vars?: TVars) => string;
}

const I18nContext = createContext<I18nValue | null>(null);

function readStoredLang(): Lang {
  try {
    return localStorage.getItem(STORAGE_KEY) === "de" ? "de" : "en";
  } catch {
    return "en";
  }
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(readStoredLang);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    // Remembered for this user going forward. Storage location (profile vs.
    // browser) is an engineering decision — browser localStorage for now.
    try {
      localStorage.setItem(STORAGE_KEY, l);
    } catch {
      /* storage unavailable — session-only is fine */
    }
  }, []);

  const t = useCallback(
    (source: string, vars?: TVars) => {
      const template = lang === "de" ? DE[source] ?? source : source;
      if (!vars) return template;
      return template.replace(/\{(\w+)\}/g, (match, key: string) =>
        key in vars ? String(vars[key]) : match
      );
    },
    [lang]
  );

  return <I18nContext.Provider value={{ lang, setLang, t }}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within an I18nProvider");
  return ctx;
}
